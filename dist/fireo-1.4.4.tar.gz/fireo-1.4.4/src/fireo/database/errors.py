""" Database related errors """


class DBConnectionError(Exception):
    pass

