from fireo.database.database import Database

db = Database()

connection = db.connect
