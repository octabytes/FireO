"""Query related errors"""


class ReferenceDocNotExist(Exception):
    pass


class InvalidKey(Exception):
    pass