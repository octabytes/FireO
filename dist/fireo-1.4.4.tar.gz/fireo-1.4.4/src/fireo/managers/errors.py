"""Manager related Errors"""


class EmptyDocument(Exception):
    pass
